import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { CommonServiceService } from '../common-service.service';

import { ToastrService } from 'ngx-toastr';
import { Subscription } from 'rxjs';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService } from '../core/services/user/user.service';
import { MessageService } from '../core/services/message/message.service';
import { HttpService } from '../core/services/http/http.service';
declare const $: any;
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  isPatient = false;
  doctors: any = [];
  patients: any = [];
  redirect = '';
  routerSubscription: Subscription;
  docId = '';
  loginForm: FormGroup;
  isSubmitted = false;
  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private user: UserService,
    private fb: FormBuilder,
    private message: MessageService,
    private http: HttpService
  ) {
    this.loginForm = this.fb.group({
      mobile: [
        '',
        [
          Validators.required,
          Validators.maxLength(10),
          Validators.minLength(10),
        ],
      ],
      password: ['', [Validators.required]],
      corporateCode: '',
      isCorporate: false,
    });
    this.routerSubscription = this.route.queryParams.subscribe((params) => {
      this.redirect = params['redirect'];
      this.docId = params['doctorId'];
    });
  }

  ngOnInit(): void {
    this.user.userSignOut();
  }

  checkType(event) {
    this.isPatient = event.target.checked ? true : false;
  }

  login() {
    this.isSubmitted = true;
    if (!this.loginForm.valid) {
      setTimeout(() => {
        this.isSubmitted = false;
      }, 10000);
      return;
    }

    const params = {
      username: this.loginForm.value.mobile,
      password: this.loginForm.value.password,
      loginType: 'P',
      corporateCode: this.loginForm.value.corporateCode,
    };
    var url = '/login/user';
    this.http.postData(url, params).subscribe(
      (response) => {
        if (!!response) {
          // response.data[0].result[0].ROLE = 'PATIENT';

          this.user.setUserLocalData(response.data[0]);
          //this.message.showSuccess('Login Successful!');
          this.router.navigate(['/assesment']);
        }
      },
      (err) => {
        console.log(err);
      }
    );
  }
}
