import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';
import { ApiUrl } from 'src/app/core/apiUrl';
import { HttpService } from 'src/app/core/services/http/http.service';
import { MessageService } from 'src/app/core/services/message/message.service';
import { UserService } from 'src/app/core/services/user/user.service';
import { HtmlCharService } from '../core/services/html-char/htmchar-service.service';

export interface Doctors {
  id: number;
  doctor_name: string;
  speciality: string;
  Education: string;
  location: string;
}

@Component({
  selector: 'app-user-result',
  templateUrl: './result.component.html',
  styleUrls: ['./result.component.css'],
})
export class UserResultComponent implements OnInit {
  score = 0;
  testId = 89;
  descriptionData = [];
  description = '';
  randomMessage = '';
  constructor(
    private http: HttpService,
    private message: MessageService,
    private user: UserService,
    private htmlCharService: HtmlCharService,
    private router: Router
  ) {}
  ngOnInit(): void {
    this.score = parseFloat(localStorage.getItem('score'));
    var value = this.score;

    this.getResultDescription();
    this.getRandomMessage();
    var element = document.getElementById('overlay');
    element.style.transform = 'translateY(' + -value + '%)';
  }

  getResultDescription(): void {
    const params = {
      query: `Call RN_Get_Test_Range(${this.testId},${this.score})`,
      params: '',
    };

    this.http.postData(ApiUrl.queryExecute, params).subscribe(
      (resp: any) => {
        if (!!resp) {
          debugger;
          this.descriptionData = resp.data ? resp.data : [];
          if (this.descriptionData.length > 0) {
            this.description = this.htmlCharService.decodeHtmlCharCodes(
              this.descriptionData[0].RESULT_DESCRIPTION
            );
          }
        }
      },
      (error) => console.log(error)
    );
  }

  getRandomMessage(): void {
    const params = {
      query: 'Call RN_GET_RANDOM_MESSAGE()',
      params: '',
    };
    this.http.postData(ApiUrl.common, params).subscribe(
      (resp: any) => {
        if (!!resp) {
          const result =
            resp.data && resp.data[0].result ? resp.data[0].result : [];
          this.randomMessage = result[0].NAME;
        }
      },
      (error) => console.log(error)
    );
  }
}
