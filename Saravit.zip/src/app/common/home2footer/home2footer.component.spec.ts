import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Home2footerComponent } from './home2footer.component';

describe('Home2footerComponent', () => {
  let component: Home2footerComponent;
  let fixture: ComponentFixture<Home2footerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Home2footerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Home2footerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
