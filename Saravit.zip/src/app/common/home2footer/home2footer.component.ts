import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home2footer',
  templateUrl: './home2footer.component.html',
  styleUrls: ['./home2footer.component.css']
})
export class Home2footerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
