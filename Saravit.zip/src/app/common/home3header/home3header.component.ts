import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home3header',
  templateUrl: './home3header.component.html',
  styleUrls: ['./home3header.component.css']
})
export class Home3headerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
