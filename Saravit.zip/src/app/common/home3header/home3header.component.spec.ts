import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Home3headerComponent } from './home3header.component';

describe('Home3headerComponent', () => {
  let component: Home3headerComponent;
  let fixture: ComponentFixture<Home3headerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Home3headerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Home3headerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
