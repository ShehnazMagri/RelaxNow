import { ViewportScroller } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { UserService } from 'src/app/core/services/user/user.service';

@Component({
  selector: 'app-home2header',
  templateUrl: './home2header.component.html',
  styleUrls: ['./home2header.component.css'],
})
export class Home2headerComponent implements OnInit {
  userData: any = {};
  userSubscription: Subscription;
  constructor(
    private viewportScroller: ViewportScroller,
    private user: UserService
  ) {}
  onClickScroll(elementId: string): void {
    this.viewportScroller.scrollToAnchor(elementId);
  }
  ngOnInit(): void {
    this.userSubscription = this.user.currentUserSubject.subscribe(
      (userData) => {
        if (userData) {
          this.userData = userData.result[0];
        }
      }
    );
  }
}
