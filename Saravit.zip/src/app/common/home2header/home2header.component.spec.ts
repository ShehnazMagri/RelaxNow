import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Home2headerComponent } from './home2header.component';

describe('Home2headerComponent', () => {
  let component: Home2headerComponent;
  let fixture: ComponentFixture<Home2headerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Home2headerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Home2headerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
