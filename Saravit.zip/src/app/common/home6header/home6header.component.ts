import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home6header',
  templateUrl: './home6header.component.html',
  styleUrls: ['./home6header.component.css']
})
export class Home6headerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
