import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home8footer',
  templateUrl: './home8footer.component.html',
  styleUrls: ['./home8footer.component.css']
})
export class Home8footerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
