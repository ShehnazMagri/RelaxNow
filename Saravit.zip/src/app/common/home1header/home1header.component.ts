import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home1header',
  templateUrl: './home1header.component.html',
  styleUrls: ['./home1header.component.css']
})
export class Home1headerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
