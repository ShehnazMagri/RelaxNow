import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Home3footerComponent } from './home3footer.component';

describe('Home3footerComponent', () => {
  let component: Home3footerComponent;
  let fixture: ComponentFixture<Home3footerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Home3footerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Home3footerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
