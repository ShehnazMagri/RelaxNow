import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home3footer',
  templateUrl: './home3footer.component.html',
  styleUrls: ['./home3footer.component.css']
})
export class Home3footerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
