import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home8header',
  templateUrl: './home8header.component.html',
  styleUrls: ['./home8header.component.css']
})
export class Home8headerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
