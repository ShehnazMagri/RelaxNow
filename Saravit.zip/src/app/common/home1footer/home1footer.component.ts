import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home1footer',
  templateUrl: './home1footer.component.html',
  styleUrls: ['./home1footer.component.css']
})
export class Home1footerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
