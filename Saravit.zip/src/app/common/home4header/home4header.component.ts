import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home4header',
  templateUrl: './home4header.component.html',
  styleUrls: ['./home4header.component.css']
})
export class Home4headerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
