import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Home5headerComponent } from './home5header.component';

describe('Home5headerComponent', () => {
  let component: Home5headerComponent;
  let fixture: ComponentFixture<Home5headerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Home5headerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Home5headerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
