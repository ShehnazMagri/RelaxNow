import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home5header',
  templateUrl: './home5header.component.html',
  styleUrls: ['./home5header.component.css']
})
export class Home5headerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
