import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home6footer',
  templateUrl: './home6footer.component.html',
  styleUrls: ['./home6footer.component.css']
})
export class Home6footerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
