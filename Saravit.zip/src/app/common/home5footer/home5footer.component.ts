import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home5footer',
  templateUrl: './home5footer.component.html',
  styleUrls: ['./home5footer.component.css']
})
export class Home5footerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
