import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Home5footerComponent } from './home5footer.component';

describe('Home5footerComponent', () => {
  let component: Home5footerComponent;
  let fixture: ComponentFixture<Home5footerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Home5footerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Home5footerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
