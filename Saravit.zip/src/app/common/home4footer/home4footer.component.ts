import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home4footer',
  templateUrl: './home4footer.component.html',
  styleUrls: ['./home4footer.component.css']
})
export class Home4footerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
