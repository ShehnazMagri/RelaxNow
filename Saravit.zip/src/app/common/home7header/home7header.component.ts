import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home7header',
  templateUrl: './home7header.component.html',
  styleUrls: ['./home7header.component.css']
})
export class Home7headerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
