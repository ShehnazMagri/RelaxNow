import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home7footer',
  templateUrl: './home7footer.component.html',
  styleUrls: ['./home7footer.component.css']
})
export class Home7footerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
