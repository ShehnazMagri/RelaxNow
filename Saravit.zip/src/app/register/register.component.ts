import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { CommonServiceService } from '../common-service.service';

import { ToastrService } from 'ngx-toastr';
import { MessageService } from '../core/services/message/message.service';
import { HttpService } from '../core/services/http/http.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService } from '../core/services/user/user.service';
import { DeviceDetectorService } from 'ngx-device-detector';

declare const $: any;
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
})
export class RegisterComponent implements OnInit {
  registerForm = new FormGroup({});

  isPatient = true;
  code = '';
  doctors: any = [];
  patients: any = [];
  regType = 'Patient Register';
  docPatient = 'Are you a Doctor?';
  isSubmitted = false;
  genderData = [];
  emailPattern = new RegExp(/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/);
  telPattern = new RegExp(
    /^(\+\d{1,2}\s?)?1?\-?\.?\s?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}$/
  );
  isAnonymous = false;

  constructor(
    private message: MessageService,
    public commonService: CommonServiceService,
    public router: Router,
    private http: HttpService,
    private fb: FormBuilder,
    private user: UserService,
    private route: ActivatedRoute,
    private deviceService: DeviceDetectorService
  ) {}

  ngOnInit(): void {
    this.createSignupForm();
  }

  /*** Intialize Register Form ***/
  createSignupForm() {
    this.registerForm = this.fb.group({
      name: ['', [Validators.required]],
      mobile: ['', [Validators.required, Validators.pattern(this.telPattern)]],
      mEmail: [
        '',
        [Validators.required, Validators.pattern(this.emailPattern)],
      ],
      password: ['', [Validators.required]],
      mName: [''],
      lName: [''],
      gender: ['', [Validators.required]],
      terms: [null, [Validators.required]],
    });
  }
  signup() {
    debugger;
    this.isSubmitted = true;
    if (this.registerForm.value.terms == false) {
      this.registerForm.get('terms').setValue(null);
    }
    if (!this.registerForm.valid) {
      setTimeout(() => {
        this.isSubmitted = false;
      }, 10000);
      return;
    }
    if (this.registerForm.value.mEmail.indexOf('mailinator.com') > -1) {
      this.message.showError('Email address is not valid.');
      return;
    }
    this.register();
  }

  register() {
    const formData = this.registerForm.value;
    this.executeRequest(formData);
  }

  /*** Execute Procedular query  ***/
  executeRequest(params: any): void {
    this.http.postData(`/register`, params).subscribe(
      (resp: any) => {
        if (!!resp) {
          if (resp.message == 'emailerror') {
            this.message.showError('Email id already exists.');
          } else if (resp.message == 'phoneerror') {
            this.message.showError('Phone number already exists.');
          } else {
            this.user.setUserLocalData(resp.data[0]);
            this.message.showSuccess('Successfully Registered!');
            this.router.navigate(['/login-page']);
          }
        }
      },
      (error) => console.log(error)
    );
  }
}
