import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './dashboard.component';
import { NgApexchartsModule } from 'ng-apexcharts';
import { CarouselModule } from 'ngx-owl-carousel-o';
import { NgSelect2Module } from 'ng-select2';
import { ForgotPasswordModule } from '../pages/authendication/forgot-password/forgot-password.module';
// import { MorrisJsModule } from 'angular-morris-js';

@NgModule({
  declarations: [DashboardComponent],
  imports: [
    CommonModule,
    DashboardRoutingModule,
    ForgotPasswordModule,
    NgApexchartsModule,
    CarouselModule,
    NgSelect2Module,
  ],
})
export class DashboardModule {}
