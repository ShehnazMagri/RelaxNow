import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pharmacy-category',
  templateUrl: './pharmacy-category.component.html',
  styleUrls: ['./pharmacy-category.component.css']
})
export class PharmacyCategoryComponent implements OnInit {
  dtOptions: DataTables.Settings = {};
  constructor() { }

  ngOnInit(): void {
    this.dtOptions = {
      searching: false,
      lengthChange: false,
      info: false,
      
    }
  }

}
