import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PharmacyCategoryComponent } from './pharmacy-category.component';

describe('PharmacyCategoryComponent', () => {
  let component: PharmacyCategoryComponent;
  let fixture: ComponentFixture<PharmacyCategoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PharmacyCategoryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PharmacyCategoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
