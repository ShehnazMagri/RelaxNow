import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PharmacyCategoryRoutingModule } from './pharmacy-category-routing.module';
import { PharmacyCategoryComponent } from './pharmacy-category.component';
import { DataTablesModule } from 'angular-datatables';


@NgModule({
  declarations: [
    PharmacyCategoryComponent
  ],
  imports: [
    CommonModule,
    PharmacyCategoryRoutingModule,
    DataTablesModule
  ]
})
export class PharmacyCategoryModule { }
