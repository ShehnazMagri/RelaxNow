import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PharmacyCategoryComponent } from './pharmacy-category.component';

const routes: Routes = [{ path: '', component: PharmacyCategoryComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PharmacyCategoryRoutingModule { }
