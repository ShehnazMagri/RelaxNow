import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductListComponent } from './product-list.component';
import { ProductListRoutingModule } from './product-list-routing.module';
import { DataTablesModule } from 'angular-datatables';
import { NgSelect2Module } from 'ng-select2';

@NgModule({
  declarations: [ ProductListComponent ],
  imports: [
    CommonModule,
    ProductListRoutingModule,
    DataTablesModule,
    NgSelect2Module
  ]
})
export class ProductListModule { }
