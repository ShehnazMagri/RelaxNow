import {
  AfterViewInit,
  Component,
  OnDestroy,
  OnInit,
  ViewChild,
  TemplateRef,
} from '@angular/core';
import { CommonServiceService } from '../../common-service.service';
import * as $ from 'jquery';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css'],
})
export class ProductListComponent implements OnInit {
  dtOptions: DataTables.Settings = {};
  products = [];
  errorMessage: string;
  name;
  id;
  key;
  constructor(
    private commonService: CommonServiceService
  ) {}

  ngOnInit(): void {
    this.getProducts();
    this.dtOptions = {
      searching: false,
      lengthChange: false,
      info: false,
      
    }
  }

  getProducts() {
    this.commonService.getProducts().subscribe(
      (data: any[]) => {
        this.products = data;
      },
      (error) => (this.errorMessage = <any>error)
    );
  }

  editModal(template: TemplateRef<any>, category) {
    this.id = category.id;
    this.name = category.name;
  }

  update() {
    let params = {
      id: this.id,
      key: this.key,
      speciality: this.name,
    };
    // this.modalRef.hide();
  }

  

  save() {
    // this.modalRef.hide();
  }

  deleteProduct() {
    this.products = this.products.filter((a) => a.id !== this.id);
    this.commonService.deleteProduct(this.id).subscribe((data: any[]) => {
      // this.modalRef.hide();
      this.getProducts();
    });
  }

  decline() {
    // this.modalRef.hide();
  }
}
