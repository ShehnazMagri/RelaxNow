import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-setting-notifications',
  templateUrl: './setting-notifications.component.html',
  styleUrls: ['./setting-notifications.component.css']
})
export class SettingNotificationsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
