import { Component, OnInit, TemplateRef } from '@angular/core';
import { CommonServiceService } from '../../common-service.service';
import * as $ from 'jquery';

@Component({
  selector: 'app-transactions',
  templateUrl: './transactions.component.html',
  styleUrls: ['./transactions.component.css']
})
export class TransactionsComponent implements OnInit {
  dtOptions: DataTables.Settings = {};
  transactionsList: any = [];
  errorMessage: string;
  id;
  constructor(public commonService: CommonServiceService) { }

  ngOnInit(): void {
    this.getTransactions();
    this.dtOptions = {
      searching: false,
      lengthChange: false,
      info: false,
      
    }
  }

  deleteModal(template: TemplateRef<any>, trans) {
    this.id = trans.id;
  }

  deleteTrans() {
    this.transactionsList = this.transactionsList.filter(a => a.id !== this.id);
    // this.modalRef.hide();
    // this.commonService.deleteTransaction(this.id).subscribe((data : any[])=>{      
    //   this.getTransactions();
    // });
  }

  decline() {
    // this.modalRef.hide();
  }
  getTransactions() {
    this.commonService.getTransactions()
      .subscribe(res => {
        this.transactionsList = res;
      },
        error => this.errorMessage = <any>error);
  }

}
