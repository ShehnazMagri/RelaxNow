import {
  AfterViewInit,
  Component,
  OnDestroy,
  OnInit,
  ViewChild,
  TemplateRef,
} from '@angular/core';
import { CommonServiceService } from '../../common-service.service';
import * as $ from 'jquery';

@Component({
  selector: 'app-pharmacy-list',
  templateUrl: './pharmacy-list.component.html',
  styleUrls: ['./pharmacy-list.component.css'],
})
export class PharmacyListComponent implements OnInit {
  dtOptions: DataTables.Settings = {};
  pharmacyList = [];
  errorMessage: string;
  name;
  id;
  key;
  constructor(
    private commonService: CommonServiceService
  ) {}

  ngOnInit(): void {
    this.getPharmacy();
    this.dtOptions = {
      searching: false,
      lengthChange: false,
      info: false,
      
    }
  }

  getPharmacy() {
    this.commonService.getPharmacy().subscribe(
      (data: any[]) => {
        this.pharmacyList = data;
      },
      (error) => (this.errorMessage = <any>error)
    );
  }

  editModal(template: TemplateRef<any>, pharmacy) {
    this.id = pharmacy.id;
    this.name = pharmacy.name;
  }

  update() {
    let params = {
      id: this.id,
      key: this.key,
      speciality: this.name,
    };
    // this.modalRef.hide();
  }

  


  save() {
    // this.modalRef.hide();
  }

  deletePharmacy() {
    this.pharmacyList = this.pharmacyList.filter((a) => a.id !== this.id);
    this.commonService.deleteProduct(this.id).subscribe((data: any[]) => {
      // this.modalRef.hide();
      this.getPharmacy();
    });
  }

  decline() {
    // this.modalRef.hide();
  }
}
