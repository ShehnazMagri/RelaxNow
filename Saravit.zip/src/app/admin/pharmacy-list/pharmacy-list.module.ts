import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PharmacyListComponent } from './pharmacy-list.component';
import { PharmacyListRoutingModule } from './pharmacy-list-routing.module';
import { DataTablesModule } from 'angular-datatables';
import { NgSelect2Module } from 'ng-select2';

@NgModule({
  declarations: [ PharmacyListComponent ],
  imports: [
    CommonModule,
    PharmacyListRoutingModule,
    DataTablesModule,
    NgSelect2Module
  ]
})
export class PharmacyListModule { }
