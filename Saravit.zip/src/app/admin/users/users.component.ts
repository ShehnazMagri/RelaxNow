import { Router } from '@angular/router';
import { MessageService } from '../../core/services/message/message.service';
import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import * as $ from 'jquery';

import { ApiUrl } from '../../core/apiUrl';
import { HttpService } from 'src/app/core/services/http/http.service';
import { NgForm } from '@angular/forms';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Subject } from 'rxjs';
import { DataTableDirective } from 'angular-datatables';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css'],
})
export class UsersComponent implements OnInit {
  patientsList: any = [];
  errorMessage: string;
  public patients = [];
  modalRef: BsModalRef;
  isSubmitted = false;
  newPassword = '';
  confirmPassword = '';
  selectedUser: any = null;

  dtTrigger: Subject<any> = new Subject<any>();
  dtOptions: DataTables.Settings = {};
  @ViewChild(DataTableDirective, { static: false })
  dtElement: DataTableDirective;
  constructor(
    private modalService: BsModalService,
    private modal: NgbModal,
    private http: HttpService,
    private message: MessageService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.getPatients();
  }

  ngAfterViewInit(): void {
    this.dtTrigger.next();
  }

  getPatients() {
    const params = {
      query: 'call RN_CUSTOMER_GET()',
      params: '',
    };
    this.http.postData(ApiUrl.common, params).subscribe(
      (resp: any) => {
        if (!!resp) {
          const result =
            resp.data && resp.data[0].result ? resp.data[0].result : [];
          this.patients = result;
          this.rerender();
        }
      },
      (error) => console.log(error)
    );
  }

  /*** Open Reset Password Modal ***/
  openModal(template: TemplateRef<any>, user): void {
    this.newPassword = '';
    this.confirmPassword = '';
    this.selectedUser = user;
    this.modalRef = this.modalService.show(template, {
      class: 'modal-md modal-dialog-centered',
    });
  }

  /*** Re-render Datatable ***/
  rerender(): void {
    if (this.dtElement) {
      this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
        // Destroy the table first
        dtInstance.destroy();
        // Call the dtTrigger to rerender again
        this.dtTrigger.next();
      });
    }
  }

  /*** UnSubscribe the events to prevent memory leakage ***/
  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }
  /*** Submit Password ***/
  submitPassword(form: NgForm): void {
    this.isSubmitted = true;
    if (!form.valid || this.newPassword !== this.confirmPassword) {
      setTimeout(() => {
        this.isSubmitted = false;
      }, 10000);
      return;
    }
    const params = {
      id: this.selectedUser.ID,
      newPassword: this.newPassword,
      type: 'P',
    };
    this.http.postData(ApiUrl.admin.updateUserPassword, params).subscribe(
      (resp: any) => {
        if (!!resp) {
          this.message.showSuccess('Password Changed Successfully!');
          this.modalRef.hide();
        }
      },
      (error) => console.log(error)
    );
  }
}
