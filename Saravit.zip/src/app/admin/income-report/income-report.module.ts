import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { IncomeReportRoutingModule } from './income-report-routing.module';
import { IncomeReportComponent } from './income-report.component';
import { NgApexchartsModule } from 'ng-apexcharts';
import { DataTablesModule } from 'angular-datatables';


@NgModule({
  declarations: [
    IncomeReportComponent
  ],
  imports: [
    CommonModule,
    IncomeReportRoutingModule,
    NgApexchartsModule,
    DataTablesModule
  ]
})
export class IncomeReportModule { }
