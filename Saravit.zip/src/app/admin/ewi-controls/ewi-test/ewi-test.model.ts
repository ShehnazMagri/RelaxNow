export class TestModel {
  ID = 0;
  Name = '';
  ACTIVE = 0;
  CatID: string | null = '';
  CREATED_Date: string | null = '';
  CREATED_BY: string | null = '';
  MODIFIED_BY: string | null = '';
  MODIFIED_DATE: string | null = '';
  DESCRIPTION: string | null = '';
}
