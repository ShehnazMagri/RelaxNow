export class AnswerModel {
  ID = 0;
  GROUPID: number | null = null;
  ANSWER: string | null = '';
  VALUE = 0;
  CREATED_BY: string | null = '';
  CREATED_Date: string | null = '';
  MODIFIED_BY: string | null = '';
  MODIFIED_Date: string | null = '';
  ACTIVE = 0;
  COLOUR = null;
  FILLTYPEID = 0;
}
