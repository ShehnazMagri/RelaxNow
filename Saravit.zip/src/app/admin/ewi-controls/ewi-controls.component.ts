import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ewi-controls',
  templateUrl: './ewi-controls.component.html',
  styleUrls: ['./ewi-controls.component.css']
})
export class EwiControlsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
