import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EwiMessagesComponent } from './ewi-messages.component';

describe('EwiGroupsComponent', () => {
  let component: EwiMessagesComponent;
  let fixture: ComponentFixture<EwiMessagesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [EwiMessagesComponent],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EwiMessagesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
