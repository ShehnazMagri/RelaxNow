import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AppointmentReportRoutingModule } from './appointment-report-routing.module';
import { AppointmentReportComponent } from './appointment-report.component';
import { NgApexchartsModule } from 'ng-apexcharts';
import { DataTablesModule } from 'angular-datatables';


@NgModule({
  declarations: [
    AppointmentReportComponent
  ],
  imports: [
    CommonModule,
    AppointmentReportRoutingModule,
    NgApexchartsModule,
    DataTablesModule
  ]
})
export class AppointmentReportModule { }
