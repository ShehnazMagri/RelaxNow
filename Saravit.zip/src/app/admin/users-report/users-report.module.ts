import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UsersReportRoutingModule } from './users-report-routing.module';
import { UsersReportComponent } from './users-report.component';
import { DataTablesModule } from 'angular-datatables';


@NgModule({
  declarations: [
    UsersReportComponent
  ],
  imports: [
    CommonModule,
    UsersReportRoutingModule,
    DataTablesModule
  ]
})
export class UsersReportModule { }
