import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-settings',
  templateUrl: './login-settings.component.html',
  styleUrls: ['./login-settings.component.css']
})
export class LoginSettingsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
