import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LoginSettingsRoutingModule } from './login-settings-routing.module';
import { LoginSettingsComponent } from './login-settings.component';


@NgModule({
  declarations: [
    LoginSettingsComponent
  ],
  imports: [
    CommonModule,
    LoginSettingsRoutingModule
  ]
})
export class LoginSettingsModule { }
