import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SettingPreferenceRoutingModule } from './setting-preference-routing.module';
import { SettingPreferenceComponent } from './setting-preference.component';


@NgModule({
  declarations: [
    SettingPreferenceComponent
  ],
  imports: [
    CommonModule,
    SettingPreferenceRoutingModule
  ]
})
export class SettingPreferenceModule { }
