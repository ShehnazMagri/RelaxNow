import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-setting-preference',
  templateUrl: './setting-preference.component.html',
  styleUrls: ['./setting-preference.component.css']
})
export class SettingPreferenceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
