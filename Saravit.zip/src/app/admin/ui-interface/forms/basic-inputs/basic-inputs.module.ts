import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BasicInputsRoutingModule } from './basic-inputs-routing.module';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    BasicInputsRoutingModule
  ]
})
export class BasicInputsModule { }
