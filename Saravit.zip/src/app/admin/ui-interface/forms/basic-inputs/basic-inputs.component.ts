import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic-inputs',
  templateUrl: './basic-inputs.component.html',
  styleUrls: ['./basic-inputs.component.css']
})
export class BasicInputsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
