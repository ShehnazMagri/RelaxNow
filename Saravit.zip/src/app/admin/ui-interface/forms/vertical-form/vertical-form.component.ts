import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vertical-form',
  templateUrl: './vertical-form.component.html',
  styleUrls: ['./vertical-form.component.css']
})
export class VerticalFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
