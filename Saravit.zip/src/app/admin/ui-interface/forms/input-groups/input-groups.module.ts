import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InputGroupsRoutingModule } from './input-groups-routing.module';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    InputGroupsRoutingModule
  ]
})
export class InputGroupsModule { }
