import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sms-gateway',
  templateUrl: './sms-gateway.component.html',
  styleUrls: ['./sms-gateway.component.css']
})
export class SmsGatewayComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
