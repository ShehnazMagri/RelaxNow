import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PastAppointmentsRoutingModule } from './past-appointments-routing.module';
import { PastAppointmentsComponent } from './past-appointments.component';
import { DataTablesModule } from 'angular-datatables';


@NgModule({
  declarations: [
    PastAppointmentsComponent
  ],
  imports: [
    CommonModule,
    PastAppointmentsRoutingModule,
    DataTablesModule
  ]
})
export class PastAppointmentsModule { }
