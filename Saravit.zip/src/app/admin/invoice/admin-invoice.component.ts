import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-invoice',
  templateUrl: './admin-invoice.component.html',
  styleUrls: ['./admin-invoice.component.css']
})
export class AdminInvoiceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
