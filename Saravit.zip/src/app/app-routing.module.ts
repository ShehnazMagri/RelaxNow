import { NgModule } from '@angular/core';
import { Routes, RouterModule, PreloadAllModules } from '@angular/router';
import { AuthGuard } from './core/guards/auth.guard';
import { CustomerAuthGuard } from './core/guards/customer.guard';

const routes: Routes = [
  { path: '', redirectTo: 'login-page', pathMatch: 'full' },
  {
    path: 'home',
    loadChildren: () => import('./home/home.module').then((m) => m.HomeModule),
  },
  {
    path: 'assesment',
    loadChildren: () =>
      import('./home-two/home-two.module').then((m) => m.HomeTwoModule),
    canActivate: [CustomerAuthGuard],
  },
  {
    path: 'result',
    loadChildren: () =>
      import('./result/result.module').then((m) => m.UserResultModule),
    canActivate: [CustomerAuthGuard],
  },
  {
    path: 'admin',
    loadChildren: () =>
      import('./admin/admin.module').then((m) => m.AdminModule),
    //canActivate: [AuthGuard],
  },
  {
    path: 'Register',
    loadChildren: () =>
      import('./register/register.module').then((m) => m.RegisterModule),
  },
  {
    path: 'login-page',
    loadChildren: () =>
      import('./login/login.module').then((m) => m.LoginModule),
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      onSameUrlNavigation: 'reload',
      preloadingStrategy: PreloadAllModules,
      relativeLinkResolution: 'legacy',
    }),
  ],
  exports: [RouterModule],
})
export class AppRoutingModule {}
