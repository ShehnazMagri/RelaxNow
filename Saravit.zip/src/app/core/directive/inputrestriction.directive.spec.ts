import { InputrestrictionDirective } from './inputrestriction.directive';

describe('InputrestrictionDirective', () => {
  it('should create an instance', () => {
    const directive = new InputrestrictionDirective();
    expect(directive).toBeTruthy();
  });
});
