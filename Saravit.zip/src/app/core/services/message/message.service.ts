import { Injectable } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import swal, { SweetAlertResult } from 'sweetalert2';
import { DeviceDetectorService } from 'ngx-device-detector';

@Injectable({
  providedIn: 'root',
})
export class MessageService {
  isMobile = false;
  constructor(
    private deviceDetect: DeviceDetectorService,
    private toastr: ToastrService
  ) {
    this.isMobile = this.deviceDetect.isMobile();
  }

  showSuccess(title: string) {
    if (!this.isMobile) {
      this.toastr.success(title);
    } else {
      swal.fire({
        icon: 'success',
        title,
        confirmButtonText: 'Ok',
      });
    }
  }

  showError(title: string) {
    if (!this.isMobile) {
      this.toastr.error(title);
    } else {
      swal.fire({
        icon: 'error',
        title,
        confirmButtonText: 'Ok',
      });
    }
  }

  /******************* confirmation dialog box (returns a promise) ********************/
  async confirm(title: string, text?: string): Promise<SweetAlertResult> {
    const result: SweetAlertResult = await swal.fire({
      title: `Do you want to ${title}?`,
      text,
      icon: 'question',
    });
    return result;
    //return null;
  }
}
