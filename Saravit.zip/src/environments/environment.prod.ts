export const environment = {
  production: true,
  BASE_URL: 'https://saravit-api.anixinventive.com/nodetest',
};
